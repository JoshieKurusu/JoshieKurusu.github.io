import { Routes, Route, useLocation } from "react-router-dom";
import Header from "./components/layout/Header";
import Footer from "./components/layout/Footer";
import Home from "./pages/Home";
import Portfolio from "./pages/Portfolio";

function AppRoutes() {
    const location = useLocation();
    const isHome = location.pathname === "/";

    return (
        <>
            <Header isHome={ isHome } />
            <Routes>
                <Route path="/" element={ <Home /> } />
                <Route path="/portfolio" element={ <Portfolio /> } />
                <Route path="/portfolio/:projectName" element={ <Portfolio /> } />
            </Routes>
            <Footer />
        </>
    );
};

export default AppRoutes;