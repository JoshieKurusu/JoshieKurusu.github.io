import React from "react";
import HeroSection from "../components/sections/HeroSection";
import ResumeSection from "../components/sections/ResumeSection";
import ProfessionalSection from "../components/sections/ProfessionalSection";
import PortfolioSection from "../components/sections/PortfolioSection";
import ExperienceSection from "../components/sections/ExperienceSection";
import ContactSection from "../components/sections/ContactSection";

const Home = () => {
    return (
        <main>
            <HeroSection />
            <ResumeSection />
            <ProfessionalSection />
            {/* SHARED BACKGROUND FOR PORTFOLIO + EXPERIENCE */}
            <div className="bg-cover bg-no-repeat pt-18 h-[clamp(2999px,_calc(3262px_-_((100vw_-_320px)_*_2.5288)),_3262px)] xs:h-[clamp(2946px,_calc(3242px_-_((100vw_-_425px)_*_1.3832)),_3242px)] sm:h-[clamp(2919px,_calc(2919px_+_((100vw_-_640px)_*_0.1811)),_2942px)] md:p-0 md:h-[clamp(2493px,_calc(2506px_-_((100vw_-_768px)_*_0.05098)),_2506px)] lg:h-[2723px]"  style={ { backgroundImage: "url('./assets/images/portfolio-bg-img.webp')" } }>
                <PortfolioSection />
                <ExperienceSection />
            </div>
            <ContactSection />
        </main>
    )
};

export default Home;