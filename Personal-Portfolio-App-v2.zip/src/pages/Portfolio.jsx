import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import PortfolioProjectGrid from "../components/ui/visuals/PortfolioProjectGrid";
import Modal from "../components/ui/modals/Modal";

const Portfolio = () => {
    const { projectName } = useParams();
    const navigate = useNavigate();

    const closeModal = () => {
        navigate("/portfolio");
    };

    return (
        <main>
            { projectName && <Modal onClose={ closeModal } /> }
            <PortfolioProjectGrid />
        </main>
    )
};

export default Portfolio;