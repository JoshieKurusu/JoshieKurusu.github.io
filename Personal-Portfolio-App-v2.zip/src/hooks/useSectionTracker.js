import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";

const useSectionTracker = (sectiondIds, threshold = 0.6) => {
    const location = useLocation();
    const isHome = location.pathname === "/";
    const [ activeSection, setActiveSection ] = useState("");

    useEffect(() => {
        if (!isHome) return;

        const observer = new IntersectionObserver((entries) => {
            const visible = entries.find((entry) => entry.isIntersecting);
            if (visible) {
                setActiveSection(visible.target.id);
            }
        }, { threshold });

        sectiondIds.forEach((id) => {
            const el = document.getElementById(id);
            if (el) observer.observe(el);
        });

        return () => observer.disconnect();
    }, [ sectiondIds, threshold, isHome ]);

    return activeSection;
};

export default useSectionTracker;