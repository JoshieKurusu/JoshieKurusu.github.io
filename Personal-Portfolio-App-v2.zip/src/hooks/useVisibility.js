import React, { useState, useEffect, useRef } from "react";

const useVisibility = (threshold = 0.5) => {
    const [isVisible, setIsVisible] = useState(false);
    const elementRef = useRef(null);

    useEffect(() => {
        const element = elementRef.current;
        if (!element) return;

        const observer = new IntersectionObserver(([entry]) => {
        if (entry.isIntersecting) setIsVisible(true);
        }, { threshold });

        observer.observe(element);
        return () => observer.unobserve(element);
    }, [threshold]);

    return [elementRef, isVisible];
};

export default useVisibility;