import React from "react";
import AbsoluteContainer from "../ui/containers/AbsoluteContainer";
import ContactCard from "../ui/cards/ContactCard";

const ContactSection = () => {
    return (
        <section className="relative h-48 bg-fixed bg-center bg-cover sm:h-75 lg:h-138" style={ { backgroundImage: "url('./assets/images/contact-bg-img.webp')" } }>
            <AbsoluteContainer translateY="translate-y-[calc(-75%_-_2.5rem)] sm:translate-y-[-70%] md:translate-y-[-60%] lg:translate-y-[-50%]">
                <ContactCard />
            </AbsoluteContainer>
        </section>
    )
};

export default ContactSection;