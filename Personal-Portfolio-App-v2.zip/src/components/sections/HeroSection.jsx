import React from "react";
import Container from "../ui/containers/Container";

const Hero = () => {
    return (
        <section className="bg-fixed bg-cover h-258" style={ { backgroundImage: "url('./assets/images/welcome-bg-img.webp')" } }>
            <Container paddingTop="pt-29 md:pt-45">
                {/* HERO CONTENT */}
                <div className="w-full max-w-xs xs:mx-auto md:max-w-md lg:max-w-xl scroll-mt-32 md:scroll-mt-20" id="home">
                    {/* NAME */}
                    <h1 className="text-white uppercase text-name leading-name font-headerBold">I<span className="text-medium-turquoise">'</span>m<br />Josh Marvey Cruz<span className="text-medium-turquoise">.</span></h1>
                    {/* ROLE */}
                    <p className="mt-5 text-white uppercase text-currentRole leading-currentRole tracking-currentRole font-subheaderLight md:mt-12">Front-end Developer</p>
                </div>
            </Container>
        </section>
    )
};

export default Hero;