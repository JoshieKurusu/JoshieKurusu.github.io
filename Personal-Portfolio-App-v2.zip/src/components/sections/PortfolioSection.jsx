import React from "react";
import { Link } from "react-router-dom";
import Container from "../ui/containers/Container";
import Heading from "../ui/typography/Heading";
import Subheading from "../ui/typography/Subheading";
import ProjectLogos from "../ui/visuals/ProjectLogos";

const PortfolioSection = () => {
    return (
        <section>
            <Container paddingTop="md:pt-23 lg:pt-46">
                <div className="mb-10 text-center uppercase md:mb-20">
                    <Heading number="02" title="Portfolio" marginBottom="mb-3 md:mb-4 lg:mb-5" />
                    <Subheading>
                        My Latest Work.
                        <Link to="/portfolio" className="inline-flex items-center ml-1 transition-all duration-300 border-b border-transparent text-light-slate-gray hover:border-light-slate-gray">
                            See More
                            <svg width="22px" height="20px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512">
                                <path fill="#C5C6C7" d="M278.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-160 160c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L210.7 256 73.4 118.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l160 160z"/>
                            </svg>
                        </Link>
                    </Subheading>
                </div>
                <ProjectLogos isHome={ true }/>
            </Container>
        </section>
    )
};

export default PortfolioSection;