import React from "react";
import Container from "../ui/containers/Container";
import Heading from "../ui/typography/Heading";
import Experience from "../ui/lists/Experience";

const ExperienceSection = () => {
    return (
        <section>
            <Container paddingTop="pt-18 md:pt-33 lg:pt-66">
                <div className="mb-6 text-center uppercase md:mb-14 scroll-mt-20 md:scroll-mt-10" id="experience">
                    <Heading number="03" title="Experience" />
                </div>
                <Experience />
            </Container>
        </section>
    )
};

export default ExperienceSection;