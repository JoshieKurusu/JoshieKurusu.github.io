import React from "react";
import Container from "../ui/containers/Container";
import Heading from "../ui/typography/Heading";
import Subheading from "../ui/typography/Subheading";
import SkillList from "../ui/lists/SkillList";

const ProfessionalSection = () => {
    return (
        <section className="bg-fixed bg-cover pb-15 pt-71 md:pb-28 md:pt-99 lg:pb-46 lg:pt-125" style={ { backgroundImage: "url('./assets/images/professional-bg-img.webp')" } }>
            <Container>
                <div className="mb-10 text-center uppercase md:mb-20 scroll-mt-20 md:scroll-mt-10" id="professional">
                    <Heading number="01" title="Professional" marginBottom="mb-3 md:mb-4 lg:mb-5" />
                    <Subheading>my Knowledge Level in Software</Subheading>
                </div>
                <SkillList />
            </Container>
        </section>
    )
};

export default ProfessionalSection;