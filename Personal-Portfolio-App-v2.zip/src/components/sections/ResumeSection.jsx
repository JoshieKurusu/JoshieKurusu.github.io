import React from "react";
import AbsoluteContainer from "../ui/containers/AbsoluteContainer";
import ResumeCard from "../ui/cards/ResumeCard";

const ResumeSection = () => {
    return (
        <section className="relative">
            <AbsoluteContainer translateY="translate-y-[calc(-62%_-_2.5rem)] md:translate-y-[calc(-58%_+_2.5rem)] lg:translate-y-[calc(-48%_+_2.5rem)]">
                <ResumeCard />
            </AbsoluteContainer>
        </section>
    )
};

export default ResumeSection;