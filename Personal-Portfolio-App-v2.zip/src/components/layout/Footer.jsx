import React from "react";

const Footer = () => {
    return (
        <footer className="bg-charcoal-navy">
            <div className="max-w-(--breakpoint-lg) mx-auto w-full py-4 px-5">
                {/* FOOTER CONTENT */}
                <div className="flex flex-col items-center justify-center w-full md:justify-normal md:flex-row">
                    {/* PERSONAL LOGO */}
                    <a href="/"><img className="w-14 h-14 md:w-10 md:h-10" src="./assets/images/J_Logo-BlueGreen.webp" alt="Teal 'J' inside brushstroke circle." /></a>
                    {/* TEXT */}
                    <p className="mx-auto mt-3 text-center text-light-slate-gray text-footer leading-footer font-subheaderLight md:mt-0">{ '\u00A9' } 2023 by Josh Marvey Cruz. All rights reserved.</p>
                </div>
            </div>
        </footer>
    )
};

export default Footer;