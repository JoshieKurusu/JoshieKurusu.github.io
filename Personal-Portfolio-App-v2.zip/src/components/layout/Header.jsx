import React, { useState, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import useSectionTracker from "../../hooks/useSectionTracker";

const Header = ({ isHome = false }) => {
    const navigate = useNavigate();
    const location = useLocation();
    const isHomePage = location.pathname === "/";
    const [ isMenuOpen, setIsMenuOpen ] = useState(false);

    const sectionsIds = [ "home", "professional", "experience", "contact" ];
    const activeSectionRaw = useSectionTracker(sectionsIds);
    const activeSection = isHomePage ? activeSectionRaw : null;

    const navigation = [
        { name: "Home", path: "#home", current: isHomePage && activeSection === "home" },
        { name: "Professional", path: "#professional", current: isHomePage && activeSection === "professional" },
        { name: "Experience", path: "#experience", current: isHomePage && activeSection === "experience" },
        { name: "Portfolio", path: "/portfolio", current: location.pathname.startsWith("/portfolio") },
        { name: "Contact", path: "#contact", current: isHomePage && activeSection === "contact" },
    ];

    const handleNavLinks = (event, path) => {
        event.preventDefault();
        if (path.startsWith("#")) {
            const targetId = path.slice(1);
            const targetElement = document.getElementById(targetId);

            if (location.pathname === "/") {
                if (targetElement) {
                    targetElement.scrollIntoView({ behavior: "smooth" });
                } else {
                    console.warn(`The ${ path } section was not found.`);
                }
            } else {
                navigate("/");
                setTimeout(() => {
                    const el = document.getElementById(targetId);
                    if (el) el.scrollIntoView({ behavior: "smooth" });
                }, 100);
            }
        } else {
            navigate(path);
        }

        if (window.innerWidth <= 767) {
            setIsMenuOpen(false);
        }
    };

    function classNames(...classes) {
        return classes.filter(Boolean).join(" ");
    };

    useEffect(() => {
        // ALWAYS LOCK HORIZONTAL SCROLL
        document.body.style.overflowX = "hidden";

        // REMOVE THE VERTICAL SCROLL IF THE MENU IS OPEN
        if (isMenuOpen) {
            document.body.style.overflowY = "hidden";
        } else {
            document.body.style.overflowY = "scroll";
        }
    }, [ isMenuOpen ]);

    return (
        <header className={ `${ isHome ? "md:bg-transparent" : "md:bg-charcoal-navy" } fixed top-0 z-30 bg-charcoal-navy start-0 end-0 md:absolute md:shadow-sm` }>
            {/* NAVBAR */}
            <nav className="max-w-(--breakpoint-lg) mx-auto h-17 w-full py-4 px-5">
                {/* NAVBAR CONTENT */}
                <div className="flex flex-row items-center justify-between w-full md:justify-normal">
                    {/* PERSONAL LOGO */}
                    <a href="/"><img src="./assets/images/J_Logo-BlueGreen.webp" alt="Teal 'J' inside brushstroke circle." className="w-10 h-10" /></a>
                    {/* NAVBAR LINKS */}
                    <ul className={ `${ isMenuOpen ? "translate-x-0" : "translate-x-full" } absolute z-50 top-0 right-0 transition-transform py-12 duration-500 ease-in-out bg-charcoal-indigo w-full h-screen flex flex-col items-center xs:w-2xs md:static md:flex-row md:justify-center md:bg-transparent md:transition-none md:translate-none md:h-auto md:w-auto md:py-0 md:mx-auto` }>
                        {
                            navigation.map((link) => (
                                <li key={ link.name }>
                                    <Link onClick={ (event) => handleNavLinks(event, link.path) } to={ link.path } className={ `${ classNames(link.current ? "text-medium-turquoise" : "text-cool-gray" ) } uppercase text-link leading-link block w-full py-3 px-3.5 font-subheaderRegular md:font-subheaderLight md:py-2 hover:text-light-slate-gray` }>{ link.name }</Link>
                                </li>
                            ))
                        }
                    </ul>
                    {/* HAMBURGER BUTTON */}
                    <button onClick={ () => setIsMenuOpen(!isMenuOpen) } type="button" className="relative w-6 h-5 cursor-pointer md:hidden" aria-label="Toggle Navigation">
                        <span className="sr-only">Open Main Menu</span>
                        <span className={ `${ isMenuOpen ? "rotate-135 bg-medium-turquoise" : "-translate-y-2 bg-white" } rounded-xl absolute left-0 z-50 block h-0.5 w-full transition-transform duration-300 ease-in-out` }></span>
                        <span className={ `${ isMenuOpen ? "opacity-0" : "opacity-100 bg-white" } rounded-xl absolute left-0 z-50 block h-0.5 w-full transition-opacity duration-300 ease-in-out` }></span>
                        <span className={ `${ isMenuOpen ? "-rotate-135 bg-medium-turquoise" : "translate-y-2 bg-white" } rounded-xl absolute left-0 z-50 block h-0.5 w-full transition-transform duration-300 ease-in-out` }></span>
                    </button>
                </div>
                {/* BACKDROP BACKGROUND */}
                {
                    isMenuOpen && (
                        <div className="fixed inset-0 z-20 bg-black/20 md:hidden" onClick={ () => setIsMenuOpen(false) }></div>
                    )
                }
            </nav>
        </header>
    )
};

export default Header;