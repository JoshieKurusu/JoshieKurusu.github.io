import React from "react";

const SelectedProjectDetail = ({ project }) => {
    return (
        <div className="w-full text-white max-w-126">
            <h1 className="text-projectTitle leading-projectTitle font-subheaderRegular">{ project.title }</h1>
            <p className="mt-2 text-projectDescription leading-projectDescription tracking-projectDescription font-subheaderLight md:mt-6">{ project.projectDescription }</p>
            <div className="w-full mt-4 truncate lg:mt-8">
                <a href={ project.link } className="text-white truncate transition-all duration-300 border-b border-transparent text-projectLink leading-projectLink font-subheaderLight hover:border-white" target="_blank">{ project.link }</a>
            </div>
        </div>
    )
};

export default SelectedProjectDetail;