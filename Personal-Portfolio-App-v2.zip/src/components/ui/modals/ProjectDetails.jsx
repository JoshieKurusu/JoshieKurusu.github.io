import React from "react";
import Card from "../cards/Card";
import SelectedProjectImage from "./SelectedProjectImage";
import SelectedProjectDetail from "./SelectedProjectDetail";

const ProjectDetails = ({ project, onClose }) => {

    return (
        <Card maxWidth="max-w-3xl">
            <div className="flex flex-col items-center justify-center gap-4 px-5 py-6 xs:py-10 sm:px-10 sm:flex-row sm:items-start md:gap-6 md:py-15 lg:px-0">
                {/* SELECTED IMAGE */}
                <SelectedProjectImage project={ project } />
                {/* SELECTED DETAILS */}
                <SelectedProjectDetail project={ project } />
                {/* CLOSE BUTTON */}
                <button type="button" onClick={ onClose } aria-label="Close Modal" className="absolute cursor-pointer top-1.5 right-1.5 sm:top-3 sm:right-3 md:top-5 md:right-5">
                    <svg className="w-6 h-6 text-light-slate-gray xs:w-7 xs:h-7 hover:text-white" xmlns="http://www.w3.org/2000/sv7" viewBox="0 0 384 512">
                        <path fill="currentColor" d="M342.6 150.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192 210.7 86.6 105.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L146.7 256 41.4 361.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192 301.3 297.4 406.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.3 256 342.6 150.6z"/>
                    </svg>
                </button>
            </div>
        </Card>
    )
};

export default ProjectDetails;