import React, { useEffect, useRef } from "react";
import { useParams } from "react-router-dom";
import data from "/src/assets/data/profileData.json";
import ProjectDetails from "./ProjectDetails";


const Modal = ({ onClose }) => {
    const { projectName } = useParams();
    const modalRef = useRef(null);

    const selectedProject = data.projects.find(project => project.projectId.toLowerCase() === projectName?.toLowerCase());

    useEffect(() => {
        // DISABLE SCROLL WHEN MODAL MOUNTS
        document.body.style.overflow = "hidden";

        const handleClickOutside = (event) => {
            if (modalRef.current && !modalRef.current.contains(event.target)) {
                onClose();
            }
        };

        document.addEventListener("click", handleClickOutside);

        return () => {
            document.removeEventListener("click", handleClickOutside);
            // RE-ENABLE SCROLL WHEN MODAL UNMOUNTS
            document.body.style.overflow = "";
        };
    }, [onClose]);

    if (!selectedProject) return null;

    return (
        <section className="fixed inset-0 z-40 flex items-center justify-center">
            {/* MODAL CONTENT */}
            <div ref={ modalRef } className="relative w-full h-full">
                <div className="absolute inset-0 flex items-center justify-center px-5 xs:px-10">
                    <ProjectDetails project={ selectedProject } onClose={ onClose } />
                </div>
            </div>
            {/* BACKDROP */}
            <div className="fixed inset-0 z-40 cursor-pointer bg-black/30"></div>
        </section>
    )
};

export default Modal;