import React from "react";

const SelectedProjectImage = ({ project }) => {
    if (!project) return null;

    return (
        <div className="w-full max-w-35 xs:max-w-40 sm:max-w-50 md:max-w-60 lg:max-w-70 xl:max-w-80">
            <img className="object-cover w-full h-full" src={ project.image } alt={ project.imageAlt } />
        </div>
    )
};

export default SelectedProjectImage;