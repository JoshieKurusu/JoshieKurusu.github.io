import React, { useState, useEffect, useRef } from "react";
import data from "/src/assets/data/profileData.json"
import useVisibility from "../../../hooks/useVisibility";
import ProjectLogoList from "./ProjectLogoList";

const ProjectLogos = ({ isHome = false }) => {
    const defaultRef = useRef(null);
    const [ visibleRef, isVisibleHook ] = useVisibility();
    const elementRef = isHome ? visibleRef : defaultRef;
    const isVisible = isHome ? isVisibleHook : true;

    const [ projects, setProjects ] = useState([]);

    useEffect(() => {
        if(data.projects.length > 0) {
            setProjects(isHome ? data.projects.slice(0, 3) : data.projects);
        }
    }, [ isHome ])
    return (
        <div className="w-full mx-auto max-w-240" ref={ elementRef }>
            <div className={ `${ isVisible ? "translate-y-0" : "md:translate-y-16"} grid grid-flow-row place-items-center md:grid-flow-col transition-all duration-700` }>
                <ProjectLogoList projects={ projects } isHome={ isHome } width="w-70 md:w-auto" height="h-70 md:h-auto" />
            </div>
        </div>
    )
};

export default ProjectLogos;