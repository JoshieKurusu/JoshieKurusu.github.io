import React, { useState, useEffect } from "react";
import data from "/src/assets/data/profileData.json"
import ProjectLogoList from "./ProjectLogoList";

const PortfolioProjectGrid = () => {
    const [ projects, setProjects ] = useState([]);

    useEffect(() => {
        if (data.projects.length > 0) {
            setProjects(data.projects);
        }
    }, []);

    return (
        <section>
            <div className="mt-17 grid grid-cols-2 grid-rows-[repeat(15,_1fr)] gap-0 md:grid-cols-4 md:grid-rows-[repeat(12,_1fr)] lg:grid-cols-7 lg:grid-rows-[repeat(6,_1fr)]">
                <ProjectLogoList projects={ projects } width="w-auto" height="h-auto"/>
            </div>
        </section>
    )
};

export default PortfolioProjectGrid;