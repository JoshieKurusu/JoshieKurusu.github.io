import React from "react";
import { useNavigate } from "react-router-dom";

const ProjectLogoList = ({ isHome, projects, width = "w-0", height = "h-0" }) => {
    const navigate = useNavigate();

    const handleClick = (projectId) => {
        if (!isHome) {
            navigate(`/portfolio/${ projectId }`);
        }
    };
    return (
        <>
            {
                projects.map((project, index) => (
                    <div key={ index } className={ `${ isHome ? index : project.projectId } ${ width } ${ height } cursor-pointer hover:brightness-80` } onClick={ () => handleClick(project.projectId) }>
                        <img src={ project.logo } alt={ project.imageAlt } className="object-cover w-full h-full" />
                    </div>
                ))
            }
        </>
    )
};

export default ProjectLogoList;