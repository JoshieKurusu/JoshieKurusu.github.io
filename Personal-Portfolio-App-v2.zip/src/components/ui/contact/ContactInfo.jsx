import React from "react";

const ContactInfo = () => {
    return (
        <div className="w-full mb-4.5 text-center max-w-xs font-subheaderLight text-white md:max-w-2xs md:text-left">
            <h4 className="text-contactHeading leading-contactHeading">Contact</h4>
            <div className="text-contactText leading-contactText tracking-contactText font-subheaderLight">
                <p className="mb-4 mt-7">Looking forward to hearing from you. Feel free to reach out with any questions or collaborations.</p>
                <a href="mailto:josh.cruz098@gmail.com">josh.cruz098@gmail.com</a>
                <p>Tel: +63 997 629 3843</p>
            </div>
        </div>
    )
};

export default ContactInfo;