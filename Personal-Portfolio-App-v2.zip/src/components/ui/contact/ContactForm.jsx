import React, { useState, useEffect } from "react";

const ContactForm = () => {
    const [ status, setStatus ] = useState("");

    const handleSubmit = async (event) => {
        event.preventDefault();
        const form = event.target;

        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }

        try {
            const response = await fetch("https://formspree.io/f/xleqpjzl", {
                method: "POST",
                body: new FormData(form),
                redirect: "manual"
            });

            if (response.ok || response.type === "opaqueredirect") {
                setStatus("SUCCESS");
                form.reset();
            } else {
                console.log("Unexecpeted response:", response);
                setStatus("ERROR");
            }
        } catch (error) {
            if (!error.message.includes("redirect")) {
                console.log("Unexpected error:", error);
            }
        }
    };

    useEffect(() => {
        if (status === "SUCCESS") {
            const timer = setTimeout(() => setStatus(""), 5000);
            return () => clearTimeout(timer);
        }
    }, [ status ])

    return (
        <form className="flex flex-col items-center justify-center gap-y-3" onSubmit={ handleSubmit }>
            {/* NAME & EMAIL FORMS */}
            <div className="flex flex-row items-center justify-center gap-4">
                <input type="text" name="name" id="name" placeholder="Name" className="w-full h-10 px-2 bg-white max-w-40" required />
                <input type="email" name="email" id="email" placeholder="Email" className="w-full h-10 px-2 bg-white max-w-40" required />
            </div>
            {/* TEL/PHONE FORM */}
            <input type="tel" name="tel" id="tel" placeholder="Phone No." className="w-full h-10 px-2 bg-white" required />
            {/* TEXTAREA  */}
            <textarea name="message" id="message" placeholder="Message" className="w-full pt-2 px-2 bg-white resize-none h-35" required />
            {/* SUBMIT BUTTON & SUCCESS WORD */}
            <div className="flex flex-col items-center justify-center w-full gap-1.5 font-subheaderLight">
                <button type="submit" className="w-full py-3 text-white cursor-pointer bg-medium-turquoise text-submitButton leading-submitButton hover:bg-charcoal-navy">Send</button>
                <span className={ `${ status === "SUCCESS" ? "opacity-100" : "opacity-0" } w-full text-center text-muted-teal transition-opacity duration-300 text-successText leading-successText` }>Thanks for submitting!</span>
            </div>
        </form>
    )
};

export default ContactForm;