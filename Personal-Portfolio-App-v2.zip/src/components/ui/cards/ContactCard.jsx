import React from "react";
import Card from "./Card";
import ContactInfo from "../contact/ContactInfo";
import ContactForm from "../contact/ContactForm";
import SocialBar from "../contact/SocialBar";

const ContactCard = () => {
    return (
        <Card id="contact" maxWidth="max-w-xl lg:max-w-2xl" paddingX="px-4 sm:px-0" paddingY="py-14" paddingTop="lg:pt-32" paddingBottom="lg:pb-16">
            <div className="flex flex-col items-center justify-center md:flex-row md:gap-x-4 md:items-start lg:gap-x-12">
                <ContactInfo />
                <div className="w-full max-w-xs md:max-w-2xs lg:max-w-84">
                    <ContactForm />
                </div>
            </div>
            <SocialBar />
        </Card>
    )
};

export default ContactCard;