import React from "react";
import Card from "./Card";
import Resume from "/src/assets/data/Josh-Marvey-Cruz-Resume-Latest.pdf";

const ResumeCard = () => {
    return (
        <Card paddingY="py-15 lg:py-0" paddingTop="lg:pt-20" paddingBottom="lg:pb-28">
            <div className="flex flex-col items-center justify-center px-8 xs:px-10 md:px-4 lg:px-0">
                {/* OWN BRAND LOGO */}
                <img src="./assets/images/J_Logo-BlueGreen.webp" alt="" className="w-20 h-20 md:w-25 md:h-25"/>
                {/* DESCRIPTION */}
                <p className="mt-10 text-center text-white uppercase font-subheaderLight text-description leading-description mb-11 lg:mt-13 lg:mb-12">Skilled front-end developer experienced in adapting responsive web designs for seamless mobile experiences. Proficient in HTML, CSS, JavaScript, and fundamentals of React. Currently seeking a full-time role that fosters growth, deepens expertise in web development, and challenges creative problem-solving.</p>
                {/* DOWNLOAD BUTTON */}
                <a href={ Resume } download="Josh-Marvey-Cruz-Resume.pdf" className="w-full py-3 text-center text-white uppercase transition-colors duration-500 ease-in-out border cursor-pointer border-medium-turquoise text-download leading-download max-w-55 font-subheaderLight hover:bg-medium-turquoise" >Download Resume</a>
            </div>
        </Card>
    )
};

export default ResumeCard;