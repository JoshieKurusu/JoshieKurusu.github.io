import React from "react";

const Card = ({ id, children, maxWidth = "max-w-xl", paddingX = "px-0", paddingY = "py-15", paddingTop = "pt-0", paddingBottom = "pb-0" }) => {
    return (
        <div className="relative z-50 w-full max-w-4xl bg-charcoal-navy scroll-mt-10 lg:scroll-mt-10" id={ id }>
            <div className={ `${ maxWidth } ${ paddingX } ${ paddingY } ${ paddingTop } ${ paddingBottom } mx-auto w-full` }>
                { children }
            </div>
        </div>
    )
};

export default Card;