import React from "react";

const Heading = ({ title, number, marginBottom = "mb-0" }) => {
    return (
        <h2 className={ `${ marginBottom } font-headerBold text-white text-heading leading-heading` }><span className="text-light-slate-gray">{ number }</span> { title }</h2>
    )
};

export default Heading;