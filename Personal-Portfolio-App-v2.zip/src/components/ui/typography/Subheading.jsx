import React from "react";

const Subheading = ({ children }) => {
  return (
        <p className="text-white font-subheaderLight text-subheading leading-subheading tracking-subheading">{ children }</p>
  )
};

export default Subheading;