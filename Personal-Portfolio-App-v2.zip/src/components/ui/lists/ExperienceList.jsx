import React from "react";
import data from "/src/assets/data/profileData.json"

const ExperienceList = () => {
    return (
        <ul className="grid w-full text-white list-none auto-rows-auto gap-y-4 md:gap-y-0 md:grid-cols-6 md:gap-x-6 lg:gap-x-16">
            {
                data.experiences.map((experience, index) => (
                    <li key={ experience.experienceId } className={ `${ index % 2 === 0 ? "md:text-left md:col-start-4 md:col-end-7" : "md:text-right md:col-start-1 md:col-end-4" } ${ index === 0 ? "md:row-start-1" : index === 1 ? "md:row-start-2" : "md:row-start-3" } col-span-2` }>
                        <div className="w-full max-w-lg mx-auto md:max-w-83 lg:max-w-90">
                            <p className={`${index % 2 === 0 ? "text-right md:text-left" : "text-right"} font-semibold text-medium-turquoise text-date leading-date tracking-date font-subheaderRegular`}>{ experience.startDate } - { experience.endDate }</p>
                            <h5 className="mt-2.5 mb-3 uppercase text-white text-company leading-company font-subheaderLight md:mt-3 md:mb-7">{ experience.company }</h5>
                            <div className="text-white text-role leading-role">
                                <h6 className="font-subheaderRegular">{ experience.role }</h6>
                                <p className="mt-2 font-subheaderLight">{ experience.roleDescription }</p>
                            </div>
                        </div>
                    </li>
                ))
            }
        </ul>
    )
};

export default ExperienceList;