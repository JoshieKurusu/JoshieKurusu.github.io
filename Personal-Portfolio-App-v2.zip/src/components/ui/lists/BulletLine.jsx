import React from "react";

const BulletLine = ({ isHome = false }) => {
    return (
        <div className={ `${ isHome ? "hidden md:block" : "hidden" } absolute top-0 z-0 -translate-x-1/2 left-1/2` }>
            <svg viewBox="0 0 4 213.8398375" className="w-4 h-[clamp(762.59px,_calc(762.59px_+_((100vw_-_768px)_*_0.03137)),_770.59px)] text-medium-turquoise fill-current lg:h-[743.37px] mt-0.5" xmlns="http://www.w3.org/2000/svg">
                <circle cx="1.852" cy="1.905" r="1.852" />
                <circle cx="1.852" cy="88.008" r="1.852" className="translate-y-[clamp(4px,_calc(4px_+_((100vw_-_768px)_*_-0.00196)),_3.5px)] lg:-translate-y-[1.2px]" />
                <circle cx="1.852" cy="211.945" r="1.852" className="translate-y-0" />
                <rect x="1.535" y="3.704" width="0.661" className="h-full" />
            </svg>
        </div>
    )
};

export default BulletLine;