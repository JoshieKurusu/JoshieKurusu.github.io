import React from "react";
import data from "/src/assets/data/profileData.json";
import useVisibility from "../../../hooks/useVisibility";

const SkillList = () => {
    const [ elementRef, isVisible ] = useVisibility();

    return (
        <div className="w-full max-w-lg mx-auto md:max-w-3xl">
            <ul className="list-none text-stone-300" ref={ elementRef }>
                {
                    data.skills.map(skill => (
                        <li key={ skill.skillId } className="flex mb-3.5 flex-col text-light-slate-gray md:items-center md:flex-row md:gap-6 last:mb-0">
                            <span className="w-32 uppercase text-skillName leading-skillName tracking-skillName font-subheaderLight md:text-right">{ skill.name }</span>
                            <div className="flex items-center w-full h-4 gap-2 overflow-hidden md:h-auto">
                                <div className="h-4 transition-all duration-1000 ease-out bg-medium-turquoise" style={{ width: isVisible ? skill.percentage : "0%" }}></div>
                                <span className={ `${ isVisible ? "opacity-100" : "opacity-0" } transition-opacity duration-500 ease-out text-skillPercentage font-subheaderLight leading-skillPercentage` }>{ skill.percentage }</span>
                            </div>
                        </li>
                    ))
                }
            </ul>
        </div>
    )
};

export default SkillList;