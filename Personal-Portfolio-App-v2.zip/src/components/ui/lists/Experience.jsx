import React from "react";
import BulletLine from "./BulletLine";
import ExperienceList from "./ExperienceList";

const Experience = () => {
    return (
        <div className="relative w-full md:mx-auto md:max-w-3xl">
            <BulletLine isHome={ true } />
            <ExperienceList />
        </div>
    )
}

export default Experience