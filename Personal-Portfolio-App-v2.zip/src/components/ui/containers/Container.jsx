import React from "react";

const Container = ({ children, paddingTop = "pt-0", paddingBottom = "pb-0"}) => {
    return (
        <div className={ `${ paddingTop } ${ paddingBottom } max-w-(--breakpoint-lg) mx-auto w-full px-5 xs:px-10 lg:px-0` }>{ children }</div>
    )
};

export default Container;