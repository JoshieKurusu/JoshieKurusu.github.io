import React from "react";

const AbsoluteContainer = ({ children, translateY = "-translate-y-[0%]" }) => {
    return (
        <div className={ `${ translateY } transition-transform z-10 absolute w-full flex justify-center items-center px-5 xs:px-10` }>{ children }</div>
    )
};

export default AbsoluteContainer;